package dev.nocheatenchant;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2170;
import net.minecraft.class_2232;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7924;

public class HoldEnchantMod implements ModInitializer {
    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(
                class_2170.method_9247("giveenchant")
                    .then(class_2170.method_9244("enchantment", class_2232.method_9441())
                        .executes(context -> {
                            var player = context.getSource().method_44023();
                            class_1799 stack = player.method_5998(class_1268.field_5808);
                            if (stack.method_7960()) {
                                player.method_7353(class_2561.method_43470("You are not holding an item!"), false);
                                return 0;
                            }

                            class_2960 enchantmentId = context.getArgument("enchantment", class_2960.class);
                            var enchantment = context.getSource().method_9211().method_30611()
                                .method_30530(class_7924.field_41265)
                                .method_10223(enchantmentId);
                            if (enchantment.isEmpty()) {
                                player.method_7353(class_2561.method_43470("Unknown enchantment: " + enchantmentId), false);
                                return 0;
                            }

                            stack.method_7978(enchantment.get(), 1);
                            player.method_7353(class_2561.method_43470("Enchanted successfully!"), false);
                            return 1;
                        })
                    )
            )
        );
    }
}